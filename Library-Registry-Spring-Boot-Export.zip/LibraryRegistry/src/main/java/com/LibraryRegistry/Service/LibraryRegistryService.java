package com.LibraryRegistry.Service;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.LibraryRegistry.CustomExceptions.EntryAlreadyMarkedException;
import com.LibraryRegistry.CustomExceptions.EntryTimeNotMarkedException;
import com.LibraryRegistry.CustomExceptions.ExitAlreadyMarkedException;
import com.LibraryRegistry.Dao.LibraryRegistryRepository;
import com.LibraryRegistry.Entity.EntryAndExitRecord;
import com.LibraryRegistry.RequestModel.EntryRequest;
import com.LibraryRegistry.RequestModel.ExitRequest;
import com.LibraryRegistry.ResponseModel.EntryAndExitResponse;
import com.LibraryRegistry.ResponseModel.EntryResponse;
import com.LibraryRegistry.ResponseModel.ExitResponse;

@Service
public class LibraryRegistryService {
	
	@Autowired
	private LibraryRegistryRepository libraryRegistryRepository;
	
	public ResponseEntity<EntryResponse> markEntry(EntryRequest entryRequest) throws EntryAlreadyMarkedException,ExitAlreadyMarkedException,EntryTimeNotMarkedException,Exception{
		
		if(libraryRegistryRepository.findByPersonnelIdentityNo(entryRequest.getPersonnelIdentityNo()).isEmpty()) {
			
			EntryAndExitRecord newEntry=new EntryAndExitRecord();
			newEntry.setPersonnelName(entryRequest.getPersonnelName());
			newEntry.setPersonnelEmail(entryRequest.getPersonnelEmail());
			newEntry.setPersonnelIdentityNo(entryRequest.getPersonnelIdentityNo());
			newEntry.setPersonnelType(entryRequest.getPersonnelType());
			newEntry.setEntryTime(LocalTime.now());
			
			newEntry=libraryRegistryRepository.save(newEntry);
			
			return ResponseEntity.ok(new EntryResponse(newEntry.getPersonnelName(),newEntry.getPersonnelEmail(),newEntry.getPersonnelIdentityNo(),newEntry.getPersonnelType()));
			
		}
		
		throw new EntryAlreadyMarkedException("Entry is already marked");
		
	}
	
	public ResponseEntity<ExitResponse> markExit(ExitRequest exitRequest) throws EntryAlreadyMarkedException,ExitAlreadyMarkedException,EntryTimeNotMarkedException,Exception{
		
		if(libraryRegistryRepository.findByPersonnelIdentityNo(exitRequest.getPersonnelIdentityNo()).isPresent()) {
			
			EntryAndExitRecord entryAndExitRecord=libraryRegistryRepository.findByPersonnelIdentityNo(exitRequest.getPersonnelIdentityNo()).get();
			
			if(entryAndExitRecord.getExitTime()==null) {
				
				entryAndExitRecord.setExitTime(LocalTime.now());
				entryAndExitRecord=libraryRegistryRepository.save(entryAndExitRecord);
				
				return ResponseEntity.ok(new ExitResponse(entryAndExitRecord.getPersonnelName(),entryAndExitRecord.getPersonnelEmail(),entryAndExitRecord.getPersonnelIdentityNo(),entryAndExitRecord.getPersonnelType()));
				
			}
			
			throw new ExitAlreadyMarkedException("Exit already marked");
			
		}
		
		throw new EntryTimeNotMarkedException("Entry not marked yet");
		
	}
	
	public ResponseEntity<List<EntryAndExitResponse>> getAllEntryAndExitRecords(){
		
		return ResponseEntity.ok(
				
				libraryRegistryRepository.findAll().stream().sorted(Comparator.comparing(EntryAndExitRecord::getRecordId).reversed()).collect(Collectors.toList()).
				stream().map(entryAndExitRecord->{
					return new EntryAndExitResponse(entryAndExitRecord.getPersonnelName(),entryAndExitRecord.getPersonnelIdentityNo(),(entryAndExitRecord.getEntryTime()!=null)?entryAndExitRecord.getEntryTime().format(DateTimeFormatter.ISO_LOCAL_TIME):"Yet to be marked",(entryAndExitRecord.getExitTime()!=null)?entryAndExitRecord.getExitTime().format(DateTimeFormatter.ISO_LOCAL_TIME):"Yet to be marked");
				}).collect(Collectors.toList())
				
				);
		
	}

}
