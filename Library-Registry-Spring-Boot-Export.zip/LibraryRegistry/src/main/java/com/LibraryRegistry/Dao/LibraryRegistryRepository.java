package com.LibraryRegistry.Dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.LibraryRegistry.Entity.EntryAndExitRecord;

@Repository
public interface LibraryRegistryRepository extends JpaRepository<EntryAndExitRecord, Long>{
	
	public Optional<EntryAndExitRecord> findByPersonnelIdentityNo(Long personnelIdentityNo);
	
	public Optional<EntryAndExitRecord> findByPersonnelEmail(String personnelEmail);

}
