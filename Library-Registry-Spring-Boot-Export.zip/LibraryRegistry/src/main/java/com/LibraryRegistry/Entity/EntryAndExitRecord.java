package com.LibraryRegistry.Entity;

import java.time.LocalTime;

import com.LibraryRegistry.AdditionalModels.PersonnelType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="entryandexit")
public class EntryAndExitRecord {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="record_id")
	private Long recordId;
	
	@Column(name="personnel_name")
	private String personnelName;
	
	@Column(name="personnel_email")
	private String personnelEmail;
	
	@Column(name="personnel_type")
	private PersonnelType personnelType;
	
	@Column(name="personnel_identity_no")
	private	Long personnelIdentityNo;
	
	@Column(name="entry_time")
	private LocalTime entryTime;
	
	@Column(name="exit_time")
	private LocalTime exitTime;

	public Long getRecordId() {
		return recordId;
	}

	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}

	public String getPersonnelName() {
		return personnelName;
	}

	public void setPersonnelName(String personnelName) {
		this.personnelName = personnelName;
	}

	public String getPersonnelEmail() {
		return personnelEmail;
	}

	public void setPersonnelEmail(String personnelEmail) {
		this.personnelEmail = personnelEmail;
	}

	public PersonnelType getPersonnelType() {
		return personnelType;
	}

	public void setPersonnelType(PersonnelType personnelType) {
		this.personnelType = personnelType;
	}

	public Long getPersonnelIdentityNo() {
		return personnelIdentityNo;
	}

	public void setPersonnelIdentityNo(Long personnelIdentityNo) {
		this.personnelIdentityNo = personnelIdentityNo;
	}

	public LocalTime getEntryTime() {
		return entryTime;
	}

	public void setEntryTime(LocalTime entryTime) {
		this.entryTime = entryTime;
	}

	public LocalTime getExitTime() {
		return exitTime;
	}

	public void setExitTime(LocalTime exitTime) {
		this.exitTime = exitTime;
	}

	@Override
	public String toString() {
		return "EntryAndExitRecord [recordId=" + recordId + ", personnelName=" + personnelName + ", personnelEmail="
				+ personnelEmail + ", personnelType=" + personnelType + ", personnelIdentityNo=" + personnelIdentityNo
				+ ", entryTime=" + entryTime + ", exitTime=" + exitTime + "]";
	}
	
}
