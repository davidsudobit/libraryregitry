package com.LibraryRegistry.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.LibraryRegistry.CustomExceptions.EntryAlreadyMarkedException;
import com.LibraryRegistry.CustomExceptions.EntryTimeNotMarkedException;
import com.LibraryRegistry.CustomExceptions.ExitAlreadyMarkedException;
import com.LibraryRegistry.RequestModel.EntryRequest;
import com.LibraryRegistry.RequestModel.ExitRequest;
import com.LibraryRegistry.ResponseModel.EntryAndExitResponse;
import com.LibraryRegistry.ResponseModel.EntryResponse;
import com.LibraryRegistry.ResponseModel.ExitResponse;
import com.LibraryRegistry.Service.LibraryRegistryService;

@RestController
@RequestMapping(path = {"libraryregistry"})
@CrossOrigin(origins = {"*"})
public class LibraryRegistryController {
	
	@Autowired
	private LibraryRegistryService libraryRegistryService;
	
	@PostMapping(path = {"/addentry","/markentry"}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<EntryResponse> markEntry(@RequestBody EntryRequest entryRequest) throws EntryAlreadyMarkedException,ExitAlreadyMarkedException,EntryTimeNotMarkedException,Exception{
		
		return libraryRegistryService.markEntry(entryRequest);
		
	}
	
	@PutMapping(path = {"/addexit","/markexit"}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<ExitResponse> markExit(@RequestBody ExitRequest exitRequest) throws EntryAlreadyMarkedException,ExitAlreadyMarkedException,EntryTimeNotMarkedException,Exception{
		
		return libraryRegistryService.markExit(exitRequest);
	}
	
	@GetMapping(path = {"getallentryandexitrecords"}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<List<EntryAndExitResponse>> getAllEntryAndExitRecords(){
		
		return libraryRegistryService.getAllEntryAndExitRecords();
		
	}

}
