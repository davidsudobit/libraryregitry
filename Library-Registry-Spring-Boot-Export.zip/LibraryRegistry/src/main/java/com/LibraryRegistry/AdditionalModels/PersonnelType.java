package com.LibraryRegistry.AdditionalModels;

public enum PersonnelType {
	
	EMPLOYEE,STUDENT

}
