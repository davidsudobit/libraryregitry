package com.LibraryRegistry.CustomExceptions;

public class ExitTimeNotMarkedException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1844231020129513879L;

	public ExitTimeNotMarkedException() {
		
	}
	
	public ExitTimeNotMarkedException(String message) {
		super(message);
	}

}
