package com.LibraryRegistry.CustomExceptions;

public class ExitAlreadyMarkedException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1167358191702688042L;

	public ExitAlreadyMarkedException() {
		
	}
	
	public ExitAlreadyMarkedException(String message) {
		super(message);
	}

}
