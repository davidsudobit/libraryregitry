package com.LibraryRegistry.CustomExceptions;

public class EntryAlreadyMarkedException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6228945314160165227L;

	public EntryAlreadyMarkedException() {
		
	}
	
	public EntryAlreadyMarkedException(String message) {
		super(message);
	}

}
