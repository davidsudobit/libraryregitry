package com.LibraryRegistry.CustomExceptions;

public class EntryTimeNotMarkedException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7283736888232089763L;

	public EntryTimeNotMarkedException() {
		
	}
	
	public EntryTimeNotMarkedException(String message) {
		super(message);
	}

}
