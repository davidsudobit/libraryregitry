package com.LibraryRegistry.GlobalExceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.LibraryRegistry.CustomExceptions.EntryAlreadyMarkedException;
import com.LibraryRegistry.CustomExceptions.EntryTimeNotMarkedException;
import com.LibraryRegistry.CustomExceptions.ExitAlreadyMarkedException;
import com.LibraryRegistry.CustomExceptions.ExitTimeNotMarkedException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(EntryAlreadyMarkedException.class)
	public ResponseEntity<String> entryAlreadyMarkedExceptionHandler(EntryAlreadyMarkedException e){
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.ALREADY_REPORTED);
	}
	
	@ExceptionHandler(ExitAlreadyMarkedException.class)
	public ResponseEntity<String> exitAlreadyMarkedExceptionHandler(ExitAlreadyMarkedException e){
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.ALREADY_REPORTED);
	}
	
	@ExceptionHandler(EntryTimeNotMarkedException.class)
	public ResponseEntity<String> entryTimeNotMarkedExceptionHandler(EntryTimeNotMarkedException e){
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.FAILED_DEPENDENCY);
	}
	
	@ExceptionHandler(ExitTimeNotMarkedException.class)
	public ResponseEntity<String> exitTimeNotMarkedExceptionHandler(ExitTimeNotMarkedException e){
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.FAILED_DEPENDENCY);
	}

}
