package com.LibraryRegistry.ResponseModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class EntryAndExitResponse {
	
	private String personnelName;
	
	private	Long personnelIdentityNo;
	
	private String entryTime;
	
	private String exitTime;
	
}
