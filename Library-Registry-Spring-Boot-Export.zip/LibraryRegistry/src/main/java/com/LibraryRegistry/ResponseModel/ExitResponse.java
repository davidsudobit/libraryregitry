package com.LibraryRegistry.ResponseModel;

import com.LibraryRegistry.AdditionalModels.PersonnelType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class ExitResponse {
	
	private String personnelName;
	
	private String personnelEmail;
	
	private Long personnelIdentityNo;
	
	private PersonnelType personnelType;

	public String getPersonnelName() {
		return personnelName;
	}

	public void setPersonnelName(String personnelName) {
		this.personnelName = personnelName;
	}

	public String getPersonnelEmail() {
		return personnelEmail;
	}

	public void setPersonnelEmail(String personnelEmail) {
		this.personnelEmail = personnelEmail;
	}

	public Long getPersonnelIdentityNo() {
		return personnelIdentityNo;
	}

	public void setPersonnelIdentityNo(Long personnelIdentityNo) {
		this.personnelIdentityNo = personnelIdentityNo;
	}

	public PersonnelType getPersonnelType() {
		return personnelType;
	}

	public void setPersonnelType(PersonnelType personnelType) {
		this.personnelType = personnelType;
	}

	@Override
	public String toString() {
		return "ExitResponse [personnelName=" + personnelName + ", personnelEmail=" + personnelEmail
				+ ", personnelIdentityNo=" + personnelIdentityNo + ", personnelType=" + personnelType + "]";
	}

}
