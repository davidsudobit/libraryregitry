package com.LibraryRegistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
